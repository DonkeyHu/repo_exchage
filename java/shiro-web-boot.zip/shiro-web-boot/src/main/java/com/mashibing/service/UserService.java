package com.mashibing.service;

import com.mashibing.entity.User;

/**
 * @author zjw
 * @description
 */
public interface UserService {

    User findByUsername(String username);

}

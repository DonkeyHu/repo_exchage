package com.atguigu.flink.source.enums;

public enum BasePageId {


}

package com.atguigu.flink.source.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AppNotice {


    Long notice_id;






}
